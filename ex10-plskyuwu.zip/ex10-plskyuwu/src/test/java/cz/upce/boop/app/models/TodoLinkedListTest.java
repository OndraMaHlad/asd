package cz.upce.boop.app.models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class TodoLinkedListTest {

    TodoLinkedList list;

    @BeforeEach
    void initializeList() {
        list = new TodoLinkedList();

        list.add(new Todo(TodoPriority.HIGH, "High 1"));
        list.add(new Todo(TodoPriority.LOW, "Low 1"));
        list.add(new Todo(TodoPriority.HIGH, "High 2"));
    }

    @Test
    void add() {
        list.add(new Todo(TodoPriority.MEDIUM, "Medium 1"));
        assertEquals(4, list.size());
    }

    @Test
    void get() {
        Todo testTodo = new Todo(TodoPriority.NOTE, "Note 1");
        UUID testTodoUUID = testTodo.id;

        list.add(testTodo);

        assertEquals(testTodo, list.get(testTodoUUID));
    }

    @Test
    void remove() {
        Todo testTodo = new Todo(TodoPriority.HIGH, "High 4");
        UUID testTodoUUID = testTodo.id;

        list.add(new Todo(TodoPriority.HIGH, "High 3"));
        list.add(testTodo);
        list.add(new Todo(TodoPriority.HIGH, "High 5"));
        list.add(new Todo(TodoPriority.HIGH, "High 6"));

        for (Todo todo : list) {
            System.out.println(todo);
        }

        assertEquals(7, list.size());
        assertEquals(testTodo, list.remove(testTodoUUID));
        assertEquals(6, list.size());

        System.out.println();

        for (Todo todo : list) {
            System.out.println(todo);
        }
    }

    @Test
    void printAll() {
        list.add(new Todo(TodoPriority.CRITICAL, "Critical 1"));
        list.add(new Todo(TodoPriority.HIGH, "High 3"));
        list.add(new Todo(TodoPriority.NOTE, "Note 1"));
        list.add(new Todo(TodoPriority.MEDIUM, "Medium 1"));
        list.add(new Todo(TodoPriority.CRITICAL, "Critical 2"));
        list.add(new Todo(TodoPriority.HIGH, "High 4"));

        for (Todo todo : list) {
            System.out.println(todo);
        }
    }
}