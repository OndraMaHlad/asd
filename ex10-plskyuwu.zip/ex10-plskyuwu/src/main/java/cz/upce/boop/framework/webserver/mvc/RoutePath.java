package cz.upce.boop.framework.webserver.mvc;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME) // Needs to be available at runtime for reflection
@Target(ElementType.METHOD)        // Apply only to methods
public @interface RoutePath {

    String path();                 // e.g., "/users/{id}"

    String method() default "GET"; // e.g., "GET", "POST" (defaults to GET)
}
