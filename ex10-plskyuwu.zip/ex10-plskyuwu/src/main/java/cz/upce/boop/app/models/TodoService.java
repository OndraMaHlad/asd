package cz.upce.boop.app.models;


import cz.upce.boop.framework.di.Inject;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class TodoService {

    private final TodoRepository todoRepository;

    @Inject
    public TodoService(TodoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    public void add(Todo todo) {
        todoRepository.getTodoList().add(todo);
    }

    public List<Todo> getAll() {
        List<Todo> list = new LinkedList<>();

        for (Todo todo : todoRepository.getTodoList()) {
            list.add(todo);
        }

        return list;
    }

    public Todo get(UUID id) {
        return todoRepository.getTodoList().get(id);
    }

    public void remove(UUID id) {
        todoRepository.getTodoList().remove(id);
    }

    public int size() {
        return todoRepository.getTodoList().size();
    }
}
