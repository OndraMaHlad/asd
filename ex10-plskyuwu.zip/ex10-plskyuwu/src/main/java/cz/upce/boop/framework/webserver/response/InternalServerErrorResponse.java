package cz.upce.boop.framework.webserver.response;

public class InternalServerErrorResponse extends BaseHttpResponse {

    public InternalServerErrorResponse(String message) {
        super("500", "Internal Server Error");
        setBody("<html><body><h1>500 Internal Server Error</h1><p>" + escapeHtml(message) + "</p></body></html>", "text/html; charset=utf-8");
    }
}
