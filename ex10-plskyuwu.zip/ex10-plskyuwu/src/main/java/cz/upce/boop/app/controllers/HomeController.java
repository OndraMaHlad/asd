package cz.upce.boop.app.controllers;

import cz.upce.boop.framework.webserver.mvc.ActionResult;
import cz.upce.boop.framework.webserver.ProcessingContext;
import cz.upce.boop.framework.webserver.mvc.RoutePath;
import cz.upce.boop.framework.collection.SimpleMap;

public class HomeController {

    @RoutePath(path = "/") // Defaults to method = "GET"
    public ActionResult index(ProcessingContext context, SimpleMap<String, String> pathParams) {
        System.out.println("HomeController.index called (Annotated)");

        SimpleMap<String, Object> model = new SimpleMap<>();
        model.put("pageTitle", "Home Page (Annotated)");
        model.put("welcomeMessage", "Welcome to the Annotated MVC Server!");
        model.put("requestPath", context.getRequest().getPath());
        return new ActionResult("home/index", model);
    }

    @RoutePath(path = "/about", method = "GET") // Explicit GET
    public ActionResult about(ProcessingContext context, SimpleMap<String, String> pathParams) {
        System.out.println("HomeController.about called (Annotated)");

        SimpleMap<String, Object> model = new SimpleMap<>();
        model.put("pageTitle", "About Us (Annotated)");
        model.put("info", "This server uses annotations for routing.");
        return new ActionResult("home/about", model);
    }
    
    @RoutePath(path = "/shutdown", method = "GET")
    public ActionResult shutdown(ProcessingContext context, SimpleMap<String, String> pathParams) {
        System.exit(0);

        SimpleMap<String, Object> model = new SimpleMap<>();
        return new ActionResult("home/index", model);
    }

    // Example of an invalid signature (won't be registered by the router)
    @RoutePath(path = "/invalid")
    public String invalidSignatureAction() {
        return "This won't work";
    }
}
