package cz.upce.boop.framework.webserver.response;

import cz.upce.boop.framework.webserver.Header;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public abstract class BaseHttpResponse implements HttpResponse {

    protected final String version = "HTTP/1.1";
    protected final String statusCode;
    protected final String reasonPhrase;
    protected final ArrayList<Header> headers;
    protected byte[] body;

    protected BaseHttpResponse(String statusCode, String reasonPhrase) {
        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
        this.headers = new ArrayList<>();
        this.body = new byte[0];
        addDefaultHeaders();
    }

    protected BaseHttpResponse(String statusCode, String reasonPhrase, ArrayList<Header> customHeaders, byte[] body) {
        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
        this.headers = customHeaders != null ? customHeaders : new ArrayList<>();
        this.body = body != null ? body : new byte[0];
        addDefaultHeaders();
    }

    protected void addDefaultHeaders() {
        // Use putIfAbsent logic if implementing Map with ArrayList
        boolean contentLengthExists = false;
        boolean contentTypeExists = false;
        boolean connectionExists = false;
        boolean serverExists = false;

        for (Header h : headers) {
            if (h.name().equalsIgnoreCase("Content-Length")) {
                contentLengthExists = true;
            }
            if (h.name().equalsIgnoreCase("Content-Type")) {
                contentTypeExists = true;
            }
            if (h.name().equalsIgnoreCase("Connection")) {
                connectionExists = true;
            }
            if (h.name().equalsIgnoreCase("Server")) {
                serverExists = true;
            }
        }

        if (!serverExists) {
            headers.add(new Header("Server", "SimpleNioPipelineServer/1.0"));
        }
        if (!connectionExists) {
            headers.add(new Header("Connection", "close"));
        }
        if (!contentLengthExists) {
            headers.add(new Header("Content-Length", String.valueOf(body.length)));
        }
        // Content-Type is usually set by subclasses
    }

    protected void setBody(String content, String contentType) {
        this.body = content.getBytes(StandardCharsets.UTF_8);
        // Remove existing Content-Type and Content-Length if they exist and update
        headers.removeIf(h -> h.name().equalsIgnoreCase("Content-Type") || h.name().equalsIgnoreCase("Content-Length"));
        headers.add(new Header("Content-Type", contentType));
        headers.add(new Header("Content-Length", String.valueOf(body.length)));
    }

    @Override
    public String getStatusLine() {
        return version + " " + statusCode + " " + reasonPhrase;
    }

    @Override
    public ArrayList<Header> getHeaders() {
        return headers;
    }

    @Override
    public byte[] getBody() {
        return body;
    }

    @Override
    public void writeToChannel(SocketChannel channel) throws IOException {
        StringBuilder responseHeaderBuilder = new StringBuilder();
        responseHeaderBuilder.append(getStatusLine()).append("\r\n");
        for (Header header : headers) {
            responseHeaderBuilder.append(header.toString()).append("\r\n");
        }
        responseHeaderBuilder.append("\r\n");

        byte[] headerBytes = responseHeaderBuilder.toString().getBytes(StandardCharsets.UTF_8);
        ByteBuffer buffer = ByteBuffer.allocate(headerBytes.length + body.length);

        buffer.put(headerBytes);
        if (body.length > 0) {
            buffer.put(body);
        }
        buffer.flip();

        // Handle potential partial writes
        while (buffer.hasRemaining()) {
            int written = channel.write(buffer);
            if (written == 0) {
                // Socket buffer is full, need to wait for OP_WRITE again
                // This requires changes in the server loop to handle partial writes
                // For simplicity here, we assume write completes or throws IOException
                System.err.println("Warning: Partial write occurred, response might be incomplete (simplification).");
                break;
            }
        }
    }

    public static String escapeHtml(String text) {
        if (text == null) {
            return "";
        }
        // Basic escaping, not exhaustive
        String escaped = text;
        escaped = escaped.replace("&", "&amp;"); // Must be first
        escaped = escaped.replace("<", "&lt;");
        escaped = escaped.replace(">", "&gt;");
        escaped = escaped.replace("\"", "&quot;");
        escaped = escaped.replace("'", "&#39;");
        return escaped;
    }
}
