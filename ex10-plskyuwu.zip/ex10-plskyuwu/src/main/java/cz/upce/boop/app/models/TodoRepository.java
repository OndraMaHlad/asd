package cz.upce.boop.app.models;

import cz.upce.boop.framework.di.Destroy;
import cz.upce.boop.framework.di.Init;
import cz.upce.boop.framework.di.Inject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.Scanner;
import java.util.UUID;

public class TodoRepository {

    private final String todoFilePath = "todos.txt";
    private final TodoLinkedList todoList = new TodoLinkedList();

    @Inject
    public TodoLinkedList getTodoList() {
        return todoList;
    }

    @Init
    public void loadTodos() {
        System.out.println("Loading todos...");
        File todoFile = new File(todoFilePath);

        try (Scanner scanner = new Scanner(todoFile)) {
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                UUID todoUUID = UUID.fromString(line);
                line = scanner.nextLine();
                LocalDateTime todoCreationTime = LocalDateTime.parse(line);
                line = scanner.nextLine();
                TodoPriority todoPriority = TodoPriority.valueOf(line.toUpperCase());
                String todoText = scanner.nextLine();

                todoList.add(new Todo(todoUUID, todoCreationTime, todoPriority, todoText));
            }
        } catch (FileNotFoundException e) {
            System.err.println("Failed to open todos file");
        }
    }

    @Destroy
    public void saveTodos() {
        System.out.println("Saving todos...");
        try (PrintWriter printWriter = new PrintWriter(todoFilePath)) {
            for (Todo todo : todoList) {
                printWriter.println(todo.id);
                printWriter.println(todo.creationTime);
                printWriter.println(todo.priority);
                printWriter.println(todo.text);
            }
        } catch (FileNotFoundException e) {
            System.err.println("Failed to save todos file");
        }
    }
}
