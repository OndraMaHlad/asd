package cz.upce.boop.app.models;

public record Product(String id, String name, String price) {

}
