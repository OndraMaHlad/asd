package cz.upce.boop.framework.webserver.request;

import cz.upce.boop.framework.collection.KeyValue;
import cz.upce.boop.framework.collection.SimpleMap;
import cz.upce.boop.framework.webserver.Header;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class HttpRequest {

    private final String method;
    private final String path;
    private final String version;
    private final ArrayList<Header> headers;
    private final String body;
    private final SimpleMap<String, String> queryParams;
    private final SimpleMap<String, String> formData;

    public HttpRequest(String method, String path, String version, ArrayList<Header> headers, String body) {
        this.version = version;
        this.headers = headers;
        this.body = body;

        // Separate path and query string
        int queryIndex = path.indexOf('?');
        if (queryIndex != -1) {
            this.path = path.substring(0, queryIndex);
            String queryString = path.substring(queryIndex + 1);
            this.queryParams = parseQueryParams(queryString);
        } else {
            this.path = path;
            this.queryParams = new SimpleMap<>(); // Empty map
        }
        // Method needs to be set after path/query parsing if method depends on them (it doesn't here)
        this.method = method;

        // Parse form data if this is a POST request with appropriate content type
        if ("POST".equalsIgnoreCase(method)) {
            String contentType = getHeaderValue("Content-Type");
            if (contentType != null) {
                if (contentType.startsWith("application/x-www-form-urlencoded")) {
                    this.formData = parseQueryParams(body); // Reuse query param parser for form data
                } else if (contentType.startsWith("multipart/form-data")) {
                    this.formData = parseMultipartFormData(body, contentType);
                } else {
                    this.formData = new SimpleMap<>();
                }
            } else {
                this.formData = new SimpleMap<>();
            }
        } else {
            this.formData = new SimpleMap<>();
        }
    }

    // Helper method to get a header value by name
    private String getHeaderValue(String headerName) {
        for (Header header : headers) {
            if (header.name().equalsIgnoreCase(headerName)) {
                return header.value();
            }
        }
        return null;
    }

    // Simple query param parser (handles basic key=value&key2=value2)
    private SimpleMap<String, String> parseQueryParams(String queryString) {
        SimpleMap<String, String> params = new SimpleMap<>();
        if (queryString == null || queryString.isEmpty()) {
            return params;
        }
        String[] pairs = queryString.split("&");
        for (String pair : pairs) {
            int eqIndex = pair.indexOf("=");
            if (eqIndex > 0) {
                String key = pair.substring(0, eqIndex);
                String value = pair.substring(eqIndex + 1);
                params.put(URLDecoder.decode(key, Charset.defaultCharset()), URLDecoder.decode(value, Charset.defaultCharset()));
            } else if (!pair.isEmpty()) {
                params.put(pair, ""); // Parameter without value
            }
        }
        return params;
    }

    // Parse multipart/form-data content
    private SimpleMap<String, String> parseMultipartFormData(String body, String contentType) {
        SimpleMap<String, String> params = new SimpleMap<>();
        if (body == null || body.isEmpty()) {
            return params;
        }

        // Extract boundary from content type
        String boundary = null;
        int boundaryIndex = contentType.indexOf("boundary=");
        if (boundaryIndex != -1) {
            boundary = contentType.substring(boundaryIndex + 9); // 9 is length of "boundary="
            // Remove any trailing parameters
            int endIndex = boundary.indexOf(';');
            if (endIndex != -1) {
                boundary = boundary.substring(0, endIndex);
            }
            // Remove quotes if present
            if (boundary.startsWith("\"") && boundary.endsWith("\"")) {
                boundary = boundary.substring(1, boundary.length() - 1);
            }
        }

        if (boundary == null) {
            return params; // Can't parse without boundary
        }

        // Split body by boundary
        String[] parts = body.split("--" + boundary);
        for (int i = 1; i < parts.length; i++) { // Skip first part (usually empty)
            String part = parts[i];
            if (part.startsWith("--")) { // End boundary
                continue;
            }

            // Find the headers and content
            int headerEnd = part.indexOf("\r\n\r\n");
            if (headerEnd == -1) {
                continue; // Malformed part
            }

            String headers = part.substring(0, headerEnd);
            String content = part.substring(headerEnd + 4); // Skip \r\n\r\n

            // Extract name from Content-Disposition header
            String name = null;
            int nameIndex = headers.indexOf("name=\"");
            if (nameIndex != -1) {
                int nameEndIndex = headers.indexOf("\"", nameIndex + 6); // 6 is length of "name=""
                if (nameEndIndex != -1) {
                    name = headers.substring(nameIndex + 6, nameEndIndex);
                }
            }

            if (name != null && !content.isEmpty()) {
                // Remove trailing \r\n if present
                if (content.endsWith("\r\n")) {
                    content = content.substring(0, content.length() - 2);
                }
                params.put(name, content);
            }
        }

        return params;
    }

    public String getMethod() {
        return method;
    }

    public String getPath() {
        return path;
    }

    public String getVersion() {
        return version;
    }

    public ArrayList<Header> getHeaders() {
        return headers;
    }

    public String getBody() {
        return body;
    }

    public SimpleMap<String, String> getQueryParams() {
        return queryParams;
    }

    public String getQueryParam(String key) {
        return queryParams.get(key);
    }

    public SimpleMap<String, String> getFormData() {
        return formData;
    }

    public String getFormValue(String key) {
        return formData.get(key);
    }

    public static HttpRequest parse(ByteBuffer buffer) throws IllegalArgumentException {
        buffer.flip();
        String rawRequest = StandardCharsets.UTF_8.decode(buffer).toString();
        if (!rawRequest.contains("\r\n\r\n")) {
            buffer.compact();
            return null; // Incomplete
        }
        buffer.clear();

        String[] requestLines = rawRequest.split("\\r\\n", -1);
        if (requestLines.length == 0 || requestLines[0].isEmpty()) {
            throw new IllegalArgumentException("Empty request");
        }

        String[] requestLineParts = requestLines[0].split(" ", 3); // Limit split to 3 parts
        if (requestLineParts.length != 3) {
            throw new IllegalArgumentException("Invalid request line: " + requestLines[0]);
        }
        String method = requestLineParts[0];
        String fullPath = requestLineParts[1]; // Includes path and query string
        String version = requestLineParts[2];

        ArrayList<Header> headers = new ArrayList<>();
        int lineIndex = 1;
        int bodyStartIndex = -1;
        while (lineIndex < requestLines.length) {
            String line = requestLines[lineIndex];
            if (line.isEmpty()) {
                bodyStartIndex = lineIndex + 1;
                break;
            }
            int separatorIndex = line.indexOf(':');
            if (separatorIndex == -1) {
                throw new IllegalArgumentException("Invalid header line: " + line);
            }
            String name = line.substring(0, separatorIndex).trim();
            String value = line.substring(separatorIndex + 1).trim();
            headers.add(new Header(name, value));
            lineIndex++;
        }

        String body = "";
        if (bodyStartIndex != -1 && bodyStartIndex < requestLines.length) {
            StringBuilder bodyBuilder = new StringBuilder();
            for (int i = bodyStartIndex; i < requestLines.length; i++) {
                bodyBuilder.append(requestLines[i]);
                if (i < requestLines.length - 1) {
                    bodyBuilder.append("\r\n");
                }
            }
            body = bodyBuilder.toString();
        }

        // Basic validation (can be expanded)
        if (!version.startsWith("HTTP/1.")) {
            throw new IllegalArgumentException("Unsupported HTTP version: " + version);
        }

        // Pass fullPath to constructor for query param parsing
        return new HttpRequest(method, fullPath, version, headers, body);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        String fullPath = path;
        if (queryParams.size() > 0) {
            sb.append("?");
            List<KeyValue<String, String>> params = queryParams.getEntries();
            for (int i = 0; i < params.size(); i++) {
                sb.append(params.get(i).key()).append("=").append(params.get(i).value());
                if (i < params.size() - 1) {
                    sb.append("&");
                }
            }
            fullPath += sb.toString();
            sb.setLength(0); // Clear StringBuilder for reuse
        }

        sb.append(method).append(" ").append(fullPath).append(" ").append(version).append("\r\n");
        for (Header header : headers) {
            sb.append(header).append("\r\n");
        }
        sb.append("\r\n");
        sb.append(body);
        return sb.toString();
    }
}
