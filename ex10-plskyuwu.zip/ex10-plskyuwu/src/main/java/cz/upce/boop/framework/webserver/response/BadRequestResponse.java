package cz.upce.boop.framework.webserver.response;

public class BadRequestResponse extends BaseHttpResponse {

    public BadRequestResponse(String message) {
        super("400", "Bad Request");
        setBody("<html><body><h1>400 Bad Request</h1><p>" + escapeHtml(message) + "</p></body></html>", "text/html; charset=utf-8");
    }
}
