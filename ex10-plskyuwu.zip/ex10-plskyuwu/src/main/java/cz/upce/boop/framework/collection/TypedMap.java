package cz.upce.boop.framework.collection;

import java.util.List;
import java.util.Objects;

public class TypedMap<K> {

    private record TypedKey<K>(K key, Class<?> clazz) {

    }

    private final SimpleMap<TypedKey<K>, Object> map;

    public TypedMap() {
        map = new SimpleMap<>();
    }

    public boolean containsKey(K key, Class<?> clazz) {
        Objects.requireNonNull(key);
        Objects.requireNonNull(clazz);

        return map.containsKey(new TypedKey<>(key, clazz));
    }

    public <V> V get(K key, Class<V> clazz) {
        Objects.requireNonNull(key);
        Objects.requireNonNull(clazz);

        return (V)map.get(new TypedKey(key, clazz));
    }

    public List<KeyValue<K, Object>> getEntries() {
        return map.getEntries().stream()
                .map(kv -> new KeyValue<>(kv.key().key(), kv.value()))
                .toList();
    }

    public <V> void put(K key, V value) {
        Objects.requireNonNull(key);
        Objects.requireNonNull(value);

        map.put(new TypedKey<>(key, (Class<V>) value.getClass()), value);
    }

    public <V> void put(K key, Class<V> clazz, V value) {
        Objects.requireNonNull(key);
        Objects.requireNonNull(value);
        Objects.requireNonNull(clazz);

        map.put(new TypedKey<>(key, clazz), value);
    }

    public int size() {
        return map.size();
    }

}
