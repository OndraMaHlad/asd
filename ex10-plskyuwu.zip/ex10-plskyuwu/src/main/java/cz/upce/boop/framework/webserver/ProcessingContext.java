package cz.upce.boop.framework.webserver;

import cz.upce.boop.framework.webserver.response.HttpResponse;
import cz.upce.boop.framework.webserver.request.HttpRequest;
import cz.upce.boop.framework.collection.TypedMap;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;

public class ProcessingContext {

    private final HttpRequest request;
    private HttpResponse response; // Can be set by middleware to finalize
    private final SelectionKey selectionKey;
    private final TaskScheduler scheduler;
    private final NonBlockingWebServer server; // Access to server instance if needed
    private final TypedMap<String> contextStorage; 

    public ProcessingContext(HttpRequest request, SelectionKey key, TaskScheduler scheduler, NonBlockingWebServer server) {
        this.request = request;
        this.selectionKey = key;
        this.scheduler = scheduler;
        this.server = server;
        this.response = null; // Not set initially
        this.contextStorage = new TypedMap<>();
    }

    public HttpRequest getRequest() {
        return request;
    }

    public SelectionKey getSelectionKey() {
        return selectionKey;
    }

    public SocketChannel getChannel() {
        return (SocketChannel) selectionKey.channel();
    }

    public TaskScheduler getScheduler() {
        return scheduler;
    }

    public NonBlockingWebServer getServer() {
        return server;
    }

    public HttpResponse getResponse() {
        return response;
    }

    public void setResponse(HttpResponse response) {
        this.response = response;
    }

    public boolean hasResponse() {
        return response != null;
    }

    public <T> void set(String key, T value) {
        contextStorage.put(key, value);
    }
    
    public <T> void set(String key,  Class<T> clazz, T value) {
        contextStorage.put(key, clazz, value);
    }

    public <T> T get(String key, Class<T> clazz) {
        return contextStorage.get(key, clazz);
    }

    public void triggerWriteIfNeeded() {
        SelectionKey key = getSelectionKey();
        // Only trigger if a response exists and OP_WRITE is not already set
        if (hasResponse() && key.isValid() && (key.interestOps() & SelectionKey.OP_WRITE) == 0) {
            try {
                key.interestOps(key.interestOps() | SelectionKey.OP_WRITE);
                // Wakeup might be needed if the selector is currently blocking in select()
                // It's generally safe to call, even if not strictly necessary in all cases.
                key.selector().wakeup();
            } catch (CancelledKeyException ignored) {
                // Channel might have been closed concurrently, cleanup will happen in main loop
                System.err.println("Error setting OP_WRITE, key likely cancelled.");
                getServer().cleanupConnection(key); // Attempt cleanup immediately
            }
        }
        // If response doesn't exist, or OP_WRITE is already set, do nothing.
    }
}
