package cz.upce.boop.framework.webserver;

@FunctionalInterface
public interface Middleware {

    /**
     * Processes the request context.
     *
     * @param context The processing context containing request, response, etc.
     * @param continuation A Runnable to execute to proceed to the next
     * middleware in the chain. Call this ONLY if processing should continue. Do
     * NOT call if a response has been set or processing should terminate for
     * other reasons.
     */
    void process(ProcessingContext context, Runnable continuation);
}
