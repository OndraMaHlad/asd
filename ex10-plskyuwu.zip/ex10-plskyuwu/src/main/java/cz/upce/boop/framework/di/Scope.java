package cz.upce.boop.framework.di;

public enum Scope {
    SINGLETON,
    TRANSIENT
}
