package cz.upce.boop;

import cz.upce.boop.app.controllers.ProductController;
import cz.upce.boop.app.controllers.HomeController;
import cz.upce.boop.app.controllers.TodoController;
import cz.upce.boop.app.models.ProductService;
import cz.upce.boop.app.models.TodoRepository;
import cz.upce.boop.app.models.TodoService;
import cz.upce.boop.framework.WebApplication;
import cz.upce.boop.framework.di.Scope;

public class Ex10 {

    public static void main(String[] args) {
        System.out.println("""
--------------------------------------------------------------------------------
               !! Popis zadání se nachází v souboru README.md !!
--------------------------------------------------------------------------------
        """);

        int port = 8088;
        String templateDir = "./src/main/resources/templates";

        WebApplication webapp = new WebApplication.Builder()
                .listenOnPort(port)
                .configureDI(di -> {
                    // Register Repositories
                    di.register(TodoRepository.class, TodoRepository.class, Scope.SINGLETON);
                    // Register Services (Example: ProductService as Singleton)
                    di.register(ProductService.class, ProductService.class, Scope.SINGLETON);
                    di.register(TodoService.class, TodoService.class, Scope.SINGLETON);
                    // Register Controllers (Crucially as TRANSIENT)
                    di.register(HomeController.class, HomeController.class, Scope.TRANSIENT);
                    di.register(ProductController.class, ProductController.class, Scope.TRANSIENT);
                    di.register(TodoController.class, TodoController.class, Scope.TRANSIENT);
                })
                .configureViews(templateDir)
                .configureRouter(router -> {
                    router.registerControllers(
                            HomeController.class,
                            ProductController.class,
                            TodoController.class
                    );
                })
                .build();

        webapp.start();
    }

}
