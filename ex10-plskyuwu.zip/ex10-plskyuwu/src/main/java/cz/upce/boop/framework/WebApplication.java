package cz.upce.boop.framework;

import cz.upce.boop.framework.di.DIContainer;
import cz.upce.boop.framework.webserver.MiddlewareNode;
import cz.upce.boop.framework.webserver.NonBlockingWebServer;
import cz.upce.boop.framework.webserver.mvc.Router;
import cz.upce.boop.framework.webserver.mvc.RoutingMiddleware;
import cz.upce.boop.framework.webserver.mvc.TemplateEngine;
import cz.upce.boop.framework.webserver.mvc.ViewRenderingMiddleware;
import java.io.IOException;
import java.util.function.Consumer;

public class WebApplication {

    private final NonBlockingWebServer server;
    private DIContainer diContainer;

    public static class Builder {

        private int port;
        private String templateDir;
        private Consumer<DIContainer> dicallback;
        private Consumer<Router> routerCallback;

        public Builder listenOnPort(int port) {
            this.port = port;
            return this;
        }

        public Builder configureDI(Consumer<DIContainer> callback) {
            this.dicallback = callback;
            return this;
        }

        public Builder configureViews(String templateDir) {
            this.templateDir = templateDir;
            return this;
        }

        public Builder configureRouter(Consumer<Router> callback) {
            this.routerCallback = callback;
            return this;
        }

        public WebApplication build() {
            return new WebApplication(port, templateDir, dicallback, routerCallback);
        }

    }

    private WebApplication(
            int port,
            String templateDir,
            Consumer<DIContainer> dicallback,
            Consumer<Router> routerCallback
    ) {
        // 1. Create and Configure DI Container
        diContainer = new DIContainer();

        // 2. Create other MVC Components
        TemplateEngine templateEngine = new TemplateEngine(templateDir);
        Router router = new Router();

        // 3. Register DI Classes and Controller Classes with the Router (for route discovery)
        dicallback.accept(diContainer);
        routerCallback.accept(router);

        // 4. Create Middleware Instances, Injecting DI Container into RoutingMiddleware
        RoutingMiddleware routingMiddleware = new RoutingMiddleware(router, diContainer);
        ViewRenderingMiddleware viewRenderingMiddleware = new ViewRenderingMiddleware(templateEngine);

        // 5. Build the Middleware Chain
        MiddlewareNode middlewareChain = MiddlewareNode.buildChain(
                routingMiddleware,
                viewRenderingMiddleware
        );

        // 6. Create the Server
        server = new NonBlockingWebServer(port, middlewareChain);
    }

    public void start() {
        try {
            // Add shutdown hook
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    server.stop();
                    diContainer.shutdown();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }));

            server.start();

        } catch (IOException e) {
            System.err.println("Failed to start server: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
