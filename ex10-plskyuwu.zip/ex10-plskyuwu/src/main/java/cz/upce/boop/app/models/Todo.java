package cz.upce.boop.app.models;

import java.time.LocalDateTime;
import java.util.UUID;

public class Todo implements Comparable<Todo> {

    public final UUID id;
    public final LocalDateTime creationTime;
    public final TodoPriority priority;
    public final String text;
    public final String name;

    public Todo(TodoPriority priority, String text) {
        id = UUID.randomUUID();
        creationTime = LocalDateTime.now();
        this.priority = priority;
        this.text = text;

        name = toString();
    }

    public Todo(UUID id, LocalDateTime creationTime, TodoPriority priority, String text) {
        this.id = id;
        this.creationTime = creationTime;
        this.priority = priority;
        this.text = text;

        name = toString();
    }

    @Override
    public int compareTo(Todo otherTodo) {
        int comparisonResult = priority.compareTo(otherTodo.priority);

        if (comparisonResult != 0) {
            return comparisonResult;
        } else {
            return creationTime.compareTo(otherTodo.creationTime);
        }
    }

    @Override
    public String toString() {
        return text + " (" + priority + " @ " + creationTime + ")";
    }
}
