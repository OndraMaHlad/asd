package cz.upce.boop.framework.webserver.response;

import cz.upce.boop.framework.webserver.Header;

public class RedirectResponse extends BaseHttpResponse {

    public RedirectResponse(String location) {
        super("301", "Redirect");

        headers.add(new Header("Location", location));
    }

}
