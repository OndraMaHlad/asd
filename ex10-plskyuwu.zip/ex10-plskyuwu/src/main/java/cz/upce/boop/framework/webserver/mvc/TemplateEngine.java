package cz.upce.boop.framework.webserver.mvc;

import cz.upce.boop.framework.collection.SimpleMap;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

class TemplateParseException extends RuntimeException {

    public TemplateParseException(String message) {
        super(message);
    }

    public TemplateParseException(String message, Throwable cause) {
        super(message, cause);
    }
}

public class TemplateEngine {

    private final String templateDirectory;
    private static final String PLACEHOLDER_START = "{{";
    private static final String PLACEHOLDER_END = "}}";
    private static final String TAG_IF = "if";
    private static final String TAG_ENDIF = "endif";
    private static final String TAG_FOREACH = "foreach";
    private static final String TAG_ENDFOREACH = "endforeach";
    private static final String TAG_ELSE = "else";

    public TemplateEngine(String templateDirectory) {
        this.templateDirectory = templateDirectory;
    }

    public String render(String templateName, SimpleMap<String, Object> model) throws IOException {
        Path templatePath = Paths.get(templateDirectory, templateName + ".template");
        if (!Files.exists(templatePath)) {
            throw new IOException("Template file not found: " + templatePath);
        }

        String templateContent = Files.readString(templatePath, StandardCharsets.UTF_8);

        try {
            // Start processing from the beginning with the initial model
            return processBlock(templateContent, 0, model).renderedContent;
        } catch (TemplateParseException e) {
            // Add template name to the error context
            throw new TemplateParseException("Error rendering template '" + templateName + "': " + e.getMessage(), e);
        } catch (Exception e) {
            throw new IOException("Unexpected error rendering template '" + templateName + "': " + e.getMessage(), e);
        }
    }

    // Represents the result of processing a block of template content
    private static class ProcessingResult {

        final String renderedContent;
        final int nextIndex; // Index in the template string after the processed block

        ProcessingResult(String renderedContent, int nextIndex) {
            this.renderedContent = renderedContent;
            this.nextIndex = nextIndex;
        }
    }

    /**
     * Processes a block of template content starting from startIndex. Handles
     * plain text, variable placeholders {{var}}, and control structures.
     * Recursively calls itself for nested blocks within if/foreach.
     *
     * @param template The full template string
     * @param startIndex The index to start processing from
     * @param context The current data context (model + loop variables)
     * @return ProcessingResult containing the rendered string and the index
     * after the processed block
     * @throws TemplateParseException for syntax errors
     */
    private ProcessingResult processBlock(String template, int startIndex, SimpleMap<String, Object> context) {
        StringBuilder result = new StringBuilder();
        int currentIndex = startIndex;

        while (currentIndex < template.length()) {
            int placeholderStart = template.indexOf(PLACEHOLDER_START, currentIndex);

            if (placeholderStart == -1) {
                // No more placeholders, append the rest and finish
                result.append(template.substring(currentIndex));
                currentIndex = template.length();
                break;
            }

            // Append text before the placeholder
            result.append(template.substring(currentIndex, placeholderStart));

            int placeholderEnd = template.indexOf(PLACEHOLDER_END, placeholderStart + PLACEHOLDER_START.length());
            if (placeholderEnd == -1) {
                throw new TemplateParseException("Unmatched '" + PLACEHOLDER_START + "' starting at index " + placeholderStart);
            }

            String tagContent = template.substring(placeholderStart + PLACEHOLDER_START.length(), placeholderEnd).trim();
            currentIndex = placeholderEnd + PLACEHOLDER_END.length(); // Move past }}

            if (tagContent.isEmpty()) {
                System.err.println("TemplateEngine Warning: Empty placeholder found: " + PLACEHOLDER_START + PLACEHOLDER_END);
                continue; // Skip empty tags
            }

            String[] tagParts = tagContent.split("\\s+", 2); // Split into command and arguments
            String command = tagParts[0].toLowerCase();

            switch (command) {
                case TAG_IF:
                    if (tagParts.length < 2) {
                        throw new TemplateParseException("Invalid if tag syntax: {{if condition}} expected. Found: {{" + tagContent + "}}");
                    }
                    ProcessingResult ifResult = handleIf(template, currentIndex, context, tagParts[1]);
                    result.append(ifResult.renderedContent);
                    currentIndex = ifResult.nextIndex;
                    break;

                case TAG_FOREACH:
                    if (tagParts.length < 2) {
                        throw new TemplateParseException("Invalid foreach tag syntax: {{foreach item in collection}} expected. Found: {{" + tagContent + "}}");
                    }
                    ProcessingResult foreachResult = handleForeach(template, currentIndex, context, tagParts[1]);
                    result.append(foreachResult.renderedContent);
                    currentIndex = foreachResult.nextIndex;
                    break;

                case TAG_ELSE:
                case TAG_ENDIF:
                case TAG_ENDFOREACH:
                    // These tags signify the end of a block being processed by a caller (handleIf/handleForeach)
                    // Return the content processed so far and the index where the end tag was found.
                    return new ProcessingResult(result.toString(), placeholderStart); // Return index *before* the end tag

                default:
                    // Assume it's a variable placeholder
                    Object value = resolveValue(tagContent, context);
                    result.append(String.valueOf(value));
                    break;
            }
        }

        // Reached end of template string normally
        return new ProcessingResult(result.toString(), currentIndex);
    }

    // --- Handler for {{if condition}} ---
    private ProcessingResult handleIf(String template, int startIndex, SimpleMap<String, Object> context, String conditionKey) {
        boolean conditionMet = evaluateCondition(resolveValue(conditionKey, context));
        StringBuilder renderedOutput = new StringBuilder();
        int currentIndex;

        // Find the matching {{else}} or {{endif}} for this if block
        BlockEndInfo endInfo = findEndOfBlock(template, startIndex, TAG_IF, TAG_ENDIF, TAG_ELSE);

        if (conditionMet) {
            // Condition is true, process the block until {{else}} or {{endif}}
            ProcessingResult trueBlockResult = processBlock(template, startIndex, context);
            renderedOutput.append(trueBlockResult.renderedContent);

            currentIndex = endInfo.endIndex + PLACEHOLDER_START.length() + TAG_ENDIF.length() + PLACEHOLDER_END.length(); // Move past {{endif}}
        } else {
            // Condition is false
            if (endInfo.foundElseAtIndex != -1) {
                // Found an {{else}}, process the block after {{else}} until {{endif}}
                int elseBlockStartIndex = endInfo.foundElseAtIndex + PLACEHOLDER_START.length() + TAG_ELSE.length() + PLACEHOLDER_END.length();
                ProcessingResult falseBlockResult = processBlock(template, elseBlockStartIndex, context);
                renderedOutput.append(falseBlockResult.renderedContent);
                // Current index should now be at the start of the {{endif}} tag
                currentIndex = falseBlockResult.nextIndex + PLACEHOLDER_START.length() + TAG_ENDIF.length() + PLACEHOLDER_END.length(); // Move past {{endif}}
            } else {
                // No {{else}}, just skip the entire block to {{endif}}
                currentIndex = endInfo.endIndex + PLACEHOLDER_START.length() + TAG_ENDIF.length() + PLACEHOLDER_END.length(); // Move past {{endif}}
            }
        }

        return new ProcessingResult(renderedOutput.toString(), currentIndex);
    }

    // --- Handler for {{foreach item in collection}} ---
    private ProcessingResult handleForeach(String template, int startIndex, SimpleMap<String, Object> context, String loopExpression) {
        String[] parts = loopExpression.split("\\s+in\\s+", 2);
        if (parts.length != 2) {
            throw new TemplateParseException("Invalid foreach syntax: 'item in collection' expected. Found: " + loopExpression);
        }
        String itemName = parts[0].trim();
        String collectionName = parts[1].trim();

        Object collectionObj = resolveValue(collectionName, context);
        Iterable<?> iterable = toIterable(collectionObj);

        if (iterable == null) {
            System.err.println("TemplateEngine Warning: Collection '" + collectionName + "' for foreach is null or not iterable.");
            iterable = Collections.emptyList(); // Iterate over empty list to handle block correctly
        }

        StringBuilder loopOutput = new StringBuilder();
        BlockEndInfo endInfo = findEndOfBlock(template, startIndex, TAG_FOREACH, TAG_ENDFOREACH, null); // No 'else' for foreach

        for (Object item : iterable) {
            // Create a nested context for this iteration
            SimpleMap<String, Object> loopContext = new SimpleMap<>(context); // Create a shallow copy
            loopContext.put(itemName, item);

            // Process the loop body with the nested context
            ProcessingResult iterationResult = processBlock(template, startIndex, loopContext);
            loopOutput.append(iterationResult.renderedContent);
            // processBlock stops when it hits the {{endforeach}}
        }

        // After the loop, the next index is after the {{endforeach}} tag
        int nextIndex = endInfo.endIndex + PLACEHOLDER_START.length() + TAG_ENDFOREACH.length() + PLACEHOLDER_END.length();
        return new ProcessingResult(loopOutput.toString(), nextIndex);
    }

    // --- Helper to find the end of a block, handling nesting ---
    private static class BlockEndInfo {

        final int endIndex; // Index where {{endTag}} starts
        final int foundElseAtIndex; // Index where {{elseTag}} starts, or -1 if not found/not applicable

        BlockEndInfo(int endIndex, int foundElseAtIndex) {
            this.endIndex = endIndex;
            this.foundElseAtIndex = foundElseAtIndex;
        }
    }

    private BlockEndInfo findEndOfBlock(String template, int startIndex, String startTag, String endTag, String elseTag) {
        int depth = 1;
        int currentIndex = startIndex;
        int foundElse = -1; // Track the *first* else at the correct depth

//        String startPlaceholder = PLACEHOLDER_START + startTag;
//        String endPlaceholder = PLACEHOLDER_START + endTag + PLACEHOLDER_END;
//        String elsePlaceholder = (elseTag != null) ? PLACEHOLDER_START + elseTag + PLACEHOLDER_END : null;
        while (currentIndex < template.length()) {
            int nextStart = template.indexOf(PLACEHOLDER_START, currentIndex);
            if (nextStart == -1) {
                throw new TemplateParseException("Could not find matching end tag '" + endTag + "' for block starting near index " + startIndex);
            }

            int nextEnd = template.indexOf(PLACEHOLDER_END, nextStart + PLACEHOLDER_START.length());
            if (nextEnd == -1) {
                throw new TemplateParseException("Unmatched '" + PLACEHOLDER_START + "' starting at index " + nextStart + " while searching for end tag '" + endTag + "'");
            }

            String tagContent = template.substring(nextStart + PLACEHOLDER_START.length(), nextEnd).trim();
            String command = tagContent.split("\\s+", 2)[0].toLowerCase();

            if (command.equals(startTag)) {
                depth++;
            } else if (command.equals(endTag)) {
                depth--;
                if (depth == 0) {
                    // Found the matching end tag for our starting block
                    return new BlockEndInfo(nextStart, foundElse);
                }
            } else if (elseTag != null && command.equals(elseTag)) {
                if (depth == 1 && foundElse == -1) {
                    // Found the 'else' for the current block level
                    foundElse = nextStart;
                }
            }

            currentIndex = nextEnd + PLACEHOLDER_END.length(); // Move past the tag we just inspected
        }

        throw new TemplateParseException("Could not find matching end tag '" + endTag + "' for block starting near index " + startIndex);
    }

    // --- Helper to evaluate condition truthiness ---
    private boolean evaluateCondition(Object value) {
        if (value == null) {
            return false;
        }
        if (value instanceof Boolean aBoolean) {
            return aBoolean;
        }
        // Consider empty strings/collections/maps as false
        if (value instanceof String string) {
            return !string.isEmpty();
        }
        if (value instanceof java.util.Collection) {
            return !((java.util.Collection<?>) value).isEmpty();
        }
        if (value instanceof SimpleMap) {
            return ((SimpleMap<?, ?>) value).size() > 0; // Check SimpleMap size
        }
        if (value.getClass().isArray()) {
            return java.lang.reflect.Array.getLength(value) > 0;
        }
        // Consider non-zero numbers as true
        if (value instanceof Number number) {
            return number.doubleValue() != 0;
        }

        return true; // Default to true for other non-null objects
    }

    // --- Helper to convert common collection types to Iterable ---
    private Iterable<?> toIterable(Object collectionObj) {
        if (collectionObj == null) {
            return null;
        }
        if (collectionObj instanceof Iterable) {
            return (Iterable<?>) collectionObj;
        }
        if (collectionObj.getClass().isArray()) {
            // Convert array to List to make it easily iterable
            // This handles primitive arrays too via autoboxing
            List<Object> list = new ArrayList<>();
            int length = java.lang.reflect.Array.getLength(collectionObj);
            for (int i = 0; i < length; i++) {
                list.add(java.lang.reflect.Array.get(collectionObj, i));
            }
            return list;
        }
        return null; // Not iterable
    }

    private Object resolveValue(String key, SimpleMap<String, Object> model) {
        // Handle direct context access first (e.g., loop variable)
        if (!key.contains(".") && model.containsKey(key)) {
            return model.get(key);
        }

        String[] parts = key.split("\\.");
        Object currentValue = model.get(parts[0]);

        if (currentValue == null) {
            // Check if the base key itself exists directly (e.g. {{item}} inside a loop)
            if (parts.length == 1 && model.containsKey(parts[0])) {
                return model.get(parts[0]);
            }
            System.err.println("TemplateEngine Warning: Key '" + parts[0] + "' not found in model for placeholder {{" + key + "}}");
            return "";
        }

        for (int i = 1; i < parts.length; i++) {
            if (currentValue == null) {
                System.err.println("TemplateEngine Warning: Cannot access property '" + parts[i] + "' because intermediate object is null in {{" + key + "}}");
                return "";
            }
            currentValue = getProperty(currentValue, parts[i], key);
        }
        return currentValue != null ? currentValue : "";
    }

    private Object getProperty(Object obj, String propertyName, String fullKey) {
        if (obj == null) {
            return null;
        }
        Class<?> objClass = obj.getClass();
        if (objClass.isRecord()) {
            String getterName = propertyName;
            try {
                Method getterMethod = objClass.getMethod(getterName);
                return getterMethod.invoke(obj);
            } catch (NoSuchMethodException e) {
                /* proceed */ } catch (IllegalAccessException | InvocationTargetException e) {
                System.err.println("TemplateEngine Warning: Error invoking getter " + getterName + " for {{" + fullKey + "}}: " + e.getMessage());
                return "[Getter Error]";
            }
        }

        String getterName = "get" + capitalize(propertyName);
        try {
            Method getterMethod = objClass.getMethod(getterName);
            return getterMethod.invoke(obj);
        } catch (NoSuchMethodException e) {
            /* proceed */ } catch (IllegalAccessException | InvocationTargetException e) {
            System.err.println("TemplateEngine Warning: Error invoking getter " + getterName + " for {{" + fullKey + "}}: " + e.getMessage());
            return "[Getter Error]";
        }
        try {
            Field field = objClass.getField(propertyName);
            return field.get(obj);
        } catch (NoSuchFieldException e) {
            /* proceed */ } catch (IllegalAccessException e) {
            System.err.println("TemplateEngine Warning: Error accessing field " + propertyName + " for {{" + fullKey + "}}: " + e.getMessage());
            return "[Field Access Error]";
        }
        if (obj instanceof SimpleMap) {
            try {
                @SuppressWarnings("unchecked")
                SimpleMap<String, ?> map = (SimpleMap<String, ?>) obj;
                return map.get(propertyName);
            } catch (ClassCastException e) {
                /* proceed */ }
        }
        // Allow accessing Map interface standard methods if obj is a Map
        if (obj instanceof Map) {
            try {
                // Very basic support for .size maybe?
                if ("size".equals(propertyName)) {
                    return ((Map<?, ?>) obj).size();
                }
                // Could potentially allow .get(key) if propertyName looks like a method call, but adds complexity
            } catch (Exception e) {
                /* proceed */ }
        }

        System.err.println("TemplateEngine Warning: Property '" + propertyName + "' not found or accessible on object of type " + objClass.getSimpleName() + " for {{" + fullKey + "}}");
        return "[Property Not Found]";
    }

    private String capitalize(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        if (str.length() == 1) {
            return str.toUpperCase();
        }
        return Character.toUpperCase(str.charAt(0)) + str.substring(1);
    }
}
