package cz.upce.boop.app.models;

import cz.upce.boop.framework.collection.SimpleMap;
import java.util.List;

public class ProductService {

    // Simulate product data
    private final SimpleMap<String, Product> products = new SimpleMap<>();

    {
        /* ... product initialization ... */
        products.put("101", new Product("101", "Gadget", "19.99"));
        products.put("102", new Product("102", "Widget", "25.50"));
    }

    public Product get(String productId) {
        return products.get(productId);
    }

    public int size() {
        return products.size();
    }

    public List<Product> getProducts() {
        return products.getEntries().stream()
                .map(e -> e.value())
                .toList();
    }

    public void add(String id, String name, String price) {
        products.put(id, new Product(id, name, price));
    }

    public void remove(String id) {
        products.remove(id);
    }

}
