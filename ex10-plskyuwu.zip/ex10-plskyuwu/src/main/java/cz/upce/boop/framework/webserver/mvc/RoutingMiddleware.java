package cz.upce.boop.framework.webserver.mvc;

import cz.upce.boop.framework.di.DIContainer;
import cz.upce.boop.framework.webserver.response.BaseHttpResponse;
import cz.upce.boop.framework.webserver.response.InternalServerErrorResponse;
import cz.upce.boop.framework.webserver.Middleware;
import cz.upce.boop.framework.webserver.ProcessingContext;
import cz.upce.boop.framework.collection.SimpleMap;
import cz.upce.boop.framework.collection.KeyValue;
import cz.upce.boop.framework.webserver.mvc.Router.DiscoveredRoute;
import cz.upce.boop.framework.webserver.mvc.Router.MatchResult;
import java.lang.reflect.InvocationTargetException;

public class RoutingMiddleware implements Middleware {

    private final Router router;
    private final DIContainer diContainer;

    public RoutingMiddleware(Router router, DIContainer diContainer) {
        this.router = router;
        this.diContainer = diContainer;
    }

    @Override
    public void process(ProcessingContext context, Runnable continuation) {
        MatchResult matchResult = router.match(context.getRequest());

        if (matchResult != null) {
            DiscoveredRoute discoveredRoute = matchResult.route();
            SimpleMap<String, String> pathParams = matchResult.pathParams();

            try {
                System.out.println("RoutingMiddleware: Getting instance of " + discoveredRoute.controllerClass().getSimpleName() + " from DI container.");
                Object controllerInstance = diContainer.getInstance(discoveredRoute.controllerClass());
                System.out.println("RoutingMiddleware: Got instance: " + controllerInstance);
                
                // Merge path parameters with form data for POST requests
                SimpleMap<String, String> requestParams = new SimpleMap<>(pathParams);
                if (context.getRequest().getMethod().equalsIgnoreCase("POST")) {
                    // Add form data to the parameters passed to the controller
                    SimpleMap<String, String> formData = context.getRequest().getFormData();
                    for (KeyValue<String, String> entry : formData.getEntries()) {
                        requestParams.put(entry.key(), entry.value());
                    }
                }

                Object result = discoveredRoute.actionMethod()
                        .invoke(controllerInstance, context, requestParams);

                if (result instanceof ActionResult actionResult) {
                    context.set("actionResult", ActionResult.class, actionResult);
                    continuation.run();
                } else {
                    System.err.println("Error: Controller action " + discoveredRoute.actionMethod().getName()
                            + " returned unexpected type: " + (result == null ? "null" : result.getClass().getName()));
                    context.setResponse(new InternalServerErrorResponse("Server error: Controller action returned invalid type."));
                }

            } catch (InvocationTargetException e) {
                // Exception occurred *inside* the controller action method
                Throwable cause = e.getCause();
                System.err.println("Error executing controller action " + discoveredRoute.actionMethod().getName() + ": " + cause.getMessage());
                cause.printStackTrace();
                context.setResponse(new InternalServerErrorResponse("Error processing request: " + BaseHttpResponse.escapeHtml(cause.getMessage())));
            } catch (Exception e) {
                // Catch errors from diContainer.getInstance() or reflection
                System.err.println("Error obtaining/invoking controller action: " + e.getMessage());
                e.printStackTrace();
                context.setResponse(new InternalServerErrorResponse("Unexpected server error during request processing."));
            }
            // If an error occurred, continuation is implicitly not called.

        } else {
            // No route matched
            continuation.run();
        }
    }
}
