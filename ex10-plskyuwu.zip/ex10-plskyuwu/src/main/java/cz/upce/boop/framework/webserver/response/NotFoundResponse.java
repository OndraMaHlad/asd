package cz.upce.boop.framework.webserver.response;

public class NotFoundResponse extends BaseHttpResponse {

    public NotFoundResponse() {
        super("404", "Not Found");
        setBody("<html><body><h1>404 Not Found</h1><p>The requested resource was not found.</p></body></html>", "text/html; charset=utf-8");
    }
}
