package cz.upce.boop.framework.webserver.mvc;

import cz.upce.boop.framework.webserver.response.BaseHttpResponse;
import cz.upce.boop.framework.webserver.Header;
import cz.upce.boop.framework.webserver.response.InternalServerErrorResponse;
import cz.upce.boop.framework.webserver.Middleware;
import cz.upce.boop.framework.webserver.ProcessingContext;
import cz.upce.boop.framework.webserver.response.RedirectResponse;
import cz.upce.boop.framework.webserver.response.TextResponse;
import java.io.IOException;

public class ViewRenderingMiddleware implements Middleware {

    private final TemplateEngine templateEngine;

    public ViewRenderingMiddleware(TemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
    }

    @Override
    public void process(ProcessingContext context, Runnable continuation) {
        ActionResult actionResult = context.get("actionResult", ActionResult.class);

        if (actionResult != null) {
            // An action result exists, attempt to render the view
            if (actionResult instanceof RedirectActionResult redirect) {
                String targetUrl = redirect.getLocation();

                context.setResponse(new RedirectResponse(targetUrl));
                return;
            }
            
            try {
                if (actionResult.getViewName() != null) {
                    // Render the template
                    String renderedHtml = templateEngine.render(actionResult.getViewName(), actionResult.getModelData());
                    // Create the response
                    TextResponse response = new TextResponse(
                            renderedHtml,
                            actionResult.getStatusCode(),
                            actionResult.getReasonPhrase()
                    );
                    // Override content type if specified in ActionResult
                    response.getHeaders().removeIf(h -> h.name().equalsIgnoreCase("Content-Type"));
                    response.getHeaders().add(new Header("Content-Type", actionResult.getContentType()));

                    context.setResponse(response);
                    // Response is set, DO NOT call continuation
                } else {
                    // ActionResult exists but has no view name (e.g., API response, redirect - not implemented here)
                    // For now, assume this means an error or requires a different response type
                    System.err.println("ActionResult found but no view name specified.");
                    context.setResponse(new InternalServerErrorResponse("Server configuration error: Action resulted in no view."));
                    // Response is set, DO NOT call continuation
                }

            } catch (IOException e) {
                System.err.println("Error rendering template '" + actionResult.getViewName() + "': " + e.getMessage());
                context.setResponse(new InternalServerErrorResponse("Error rendering view: " + BaseHttpResponse.escapeHtml(e.getMessage())));
                // Response is set, DO NOT call continuation
            } catch (Exception e) {
                System.err.println("Unexpected error during view rendering: " + e.getMessage());
                e.printStackTrace();
                context.setResponse(new InternalServerErrorResponse("Unexpected server error during view rendering."));
                // Response is set, DO NOT call continuation
            }
        } else {
            // No ActionResult found in context, proceed to the next middleware
            // This allows subsequent middleware (like a final 404 handler or static file server) to run
            // if the RoutingMiddleware didn't find a route or if a previous middleware handled the request.
            continuation.run();
        }
    }
}
