package cz.upce.boop.framework.webserver.response;

import cz.upce.boop.framework.webserver.Header;
import java.io.IOException;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;

public interface HttpResponse {

    String getStatusLine();

    ArrayList<Header> getHeaders();

    byte[] getBody();

    void writeToChannel(SocketChannel channel) throws IOException;
}
