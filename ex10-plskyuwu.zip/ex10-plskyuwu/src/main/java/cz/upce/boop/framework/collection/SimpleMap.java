package cz.upce.boop.framework.collection;

import java.util.ArrayList;
import java.util.List;

public class SimpleMap<K, V> {

    private final List<KeyValue<K, V>> entries;

    public SimpleMap() {
        this.entries = new ArrayList<>();
    }

    public SimpleMap(SimpleMap<K, V> simplemap) {
        this.entries = new ArrayList<>();

        for (KeyValue<K, V> entry : simplemap.entries) {
            this.entries.add(entry);
        }
    }

    public void put(K key, V value) {
        // Remove existing entry with the same key, if any
        entries.removeIf(kv -> kv.key().equals(key));
        entries.add(new KeyValue<>(key, value));
    }

    public V get(K key) {
        for (KeyValue<K, V> kv : entries) {
            if (kv.key().equals(key)) {
                return kv.value();
            }
        }
        return null; // Not found
    }

    public boolean containsKey(K key) {
        for (KeyValue<K, V> kv : entries) {
            if (kv.key().equals(key)) {
                return true;
            }
        }
        return false;
    }

    public void remove(K key) {
        entries.removeIf(kv -> kv.key().equals(key));
    }

    // Method to get all entries for iteration (e.g., in template engine)
    public List<KeyValue<K, V>> getEntries() {
        return new ArrayList<>(entries); // Return a copy
    }

    public int size() {
        return entries.size();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("{");
        for (int i = 0; i < entries.size(); i++) {
            sb.append(entries.get(i).key()).append("=").append(entries.get(i).value());
            if (i < entries.size() - 1) {
                sb.append(", ");
            }
        }
        sb.append("}");
        return sb.toString();
    }

}
