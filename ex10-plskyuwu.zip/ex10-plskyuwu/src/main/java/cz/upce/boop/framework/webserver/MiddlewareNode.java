package cz.upce.boop.framework.webserver;

import cz.upce.boop.framework.webserver.response.NotFoundResponse;
import cz.upce.boop.framework.webserver.response.InternalServerErrorResponse;

public class MiddlewareNode {

    private final Middleware middleware;
    private final MiddlewareNode next; // Reference to the next node in the chain

    public MiddlewareNode(Middleware middleware, MiddlewareNode next) {
        this.middleware = middleware;
        this.next = next;
    }

    /**
     * Executes the middleware chain starting from this node. This method should
     * be called on the IO thread.
     */
    public void executeChain(ProcessingContext context) {
        // If a response is already set (e.g., by error handling or async completion), stop.
        if (context.hasResponse()) {
            // Ensure write is triggered if needed (might have been set by async handler)
            context.triggerWriteIfNeeded();
            return;
        }

        // Create the continuation Runnable for the *current* middleware.
        // This Runnable, when executed, will trigger the processing of the *next* node.
        Runnable continuation = () -> {
            if (next != null) {
                try {
                    // Proceed to the next node in the chain
                    next.executeChain(context);
                } catch (Exception e) {
                    // Handle errors occurring during the *call* to the next node's execution
                    handleProcessingError(context, "Error invoking next middleware node", e);
                }
            } else {
                // Reached the end of the explicit chain.
                // If no middleware set a response, this is typically a 404 situation.
                if (!context.hasResponse()) {
                    System.out.println("[" + Thread.currentThread().getName() + "] Middleware chain ended without response for "
                            + (context.getRequest() != null ? context.getRequest().getPath() : "[unknown path]")
                            + ". Sending 404.");
                    context.setResponse(new NotFoundResponse());
                    context.triggerWriteIfNeeded(); // Trigger write for the 404 response
                }
                // If a response *was* set by the last middleware, processing ends naturally.
            }
        };

        // Execute the current middleware's process method
        try {
            this.middleware.process(context, continuation);
        } catch (Exception e) {
            // Handle errors occurring *within* the current middleware's synchronous execution
            handleProcessingError(context, "Error in middleware " + this.middleware.getClass().getSimpleName(), e);
        }
    }

    // Helper to handle errors during pipeline execution
    private void handleProcessingError(ProcessingContext context, String message, Exception e) {
        System.err.println("[" + Thread.currentThread().getName() + "] " + message + ": " + e.getMessage());
        e.printStackTrace();
        if (!context.hasResponse()) { // Don't overwrite an existing response
            context.setResponse(new InternalServerErrorResponse("Server error during processing: " + escapeHtml(e.getMessage())));
        }
        // Ensure write is triggered for the error response
        context.triggerWriteIfNeeded();
        // Stop further pipeline execution implicitly by not calling continuation
    }

    // --- Static helper to build the chain ---
    /**
     * Builds the linked list chain of middleware nodes.
     *
     * @param middlewares The middleware instances in the desired order of
     * execution.
     * @return The head node of the middleware chain, or null if no middleware
     * is provided.
     */
    public static MiddlewareNode buildChain(Middleware... middlewares) {
        MiddlewareNode head = null; // Represents the *next* node to be linked when iterating backwards
        for (int i = middlewares.length - 1; i >= 0; i--) {
            if (middlewares[i] == null) {
                throw new IllegalArgumentException("Middleware cannot be null.");
            }
            head = new MiddlewareNode(middlewares[i], head);
        }
        return head; // Return the first node in the chain
    }

    private static String escapeHtml(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
