package cz.upce.boop.framework.webserver.mvc;

import cz.upce.boop.framework.collection.SimpleMap;

public class ActionResult {

    private final String viewName;
    private final SimpleMap<String, Object> modelData; // Using SimpleMap
    private final String statusCode;
    private final String reasonPhrase;
    private final String contentType;

    // Constructor for simple view rendering
    public ActionResult(String viewName, SimpleMap<String, Object> modelData) {
        this(viewName, modelData, "200", "OK", "text/html; charset=utf-8");
    }

    // Full constructor
    public ActionResult(String viewName, SimpleMap<String, Object> modelData, String statusCode, String reasonPhrase, String contentType) {
        this.viewName = viewName; // Can be null if not rendering a view (e.g., redirect)
        this.modelData = modelData != null ? modelData : new SimpleMap<>();
        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
        this.contentType = contentType;
    }

    // Getters
    public String getViewName() {
        return viewName;
    }

    public SimpleMap<String, Object> getModelData() {
        return modelData;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public String getReasonPhrase() {
        return reasonPhrase;
    }

    public String getContentType() {
        return contentType;
    }
}
