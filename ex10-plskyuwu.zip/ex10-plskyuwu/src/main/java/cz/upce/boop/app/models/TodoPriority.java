package cz.upce.boop.app.models;

public enum TodoPriority {
    CRITICAL("Critical"), URGENT("Urgent"), HIGH("High"),
    MEDIUM("Medium"), LOW("Low"), NOTE("Note");

    private final String name;

    TodoPriority(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
