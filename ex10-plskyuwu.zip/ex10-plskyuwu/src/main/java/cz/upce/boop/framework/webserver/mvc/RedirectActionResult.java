package cz.upce.boop.framework.webserver.mvc;

public class RedirectActionResult extends ActionResult {

    private final String location;

    public RedirectActionResult(String location) {
        super(null, null);

        this.location = location;
    }

    public String getLocation() {
        return location;
    }

}
