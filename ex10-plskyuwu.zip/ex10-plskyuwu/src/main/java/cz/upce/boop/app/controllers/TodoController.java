package cz.upce.boop.app.controllers;

import cz.upce.boop.app.models.Todo;
import cz.upce.boop.app.models.TodoPriority;
import cz.upce.boop.app.models.TodoService;
import cz.upce.boop.framework.collection.SimpleMap;
import cz.upce.boop.framework.di.Inject;
import cz.upce.boop.framework.webserver.ProcessingContext;
import cz.upce.boop.framework.webserver.mvc.ActionResult;
import cz.upce.boop.framework.webserver.mvc.RedirectActionResult;
import cz.upce.boop.framework.webserver.mvc.RoutePath;

import java.util.UUID;

public class TodoController {

    private final TodoService todoService;

    @Inject
    public TodoController(TodoService todoService) {
        this.todoService = todoService;
    }

    @RoutePath(path = "/todos", method = "GET")
    public ActionResult index(ProcessingContext context, SimpleMap<String, String> pathParams) {
        System.out.println("TodoController.index called (Annotated)");

        SimpleMap<String, Object> model = new SimpleMap<>();
        model.put("pageTitle", "Todo List (Annotated)");
        model.put("allTodos", todoService.getAll());
        model.put("todoCount", todoService.size());
        return new ActionResult("todos/index", model);
    }

    @RoutePath(path = "/todos-create", method = "POST")
    public ActionResult create(ProcessingContext context, SimpleMap<String, String> params) {

        System.out.println("Current priority key value = " + params.get("priority"));
        System.out.println("Current text key value = " + params.get("text"));

        String todoPriority = params.get("priority");
        String text = params.get("text");

        if (text == null || text.isEmpty() || todoPriority == null || todoPriority.isEmpty()) {
            SimpleMap<String, Object> errorModel = new SimpleMap<>();
            errorModel.put("pageTitle", "Error");
            errorModel.put("error", "Text and/or priority is required");
            return new ActionResult("todos/error", errorModel);
        }

        todoService.add(new Todo(TodoPriority.valueOf(todoPriority.trim()), text.trim()));

        return new RedirectActionResult("/todos");
    }

    @RoutePath(path = "/todos-delete/{id}", method = "POST")
    public ActionResult remove(ProcessingContext context, SimpleMap<String, String> params) {
        String id = params.get("id");

        todoService.remove(UUID.fromString(id));

        return new RedirectActionResult("/todos");
    }

    @RoutePath(path = "/todos/{id}", method = "GET")
    public ActionResult todoDetail(ProcessingContext context, SimpleMap<String, String> pathParams) {
        String todoId = pathParams.get("id");
        System.out.println("TodoController.todoDetail called for ID: " + todoId + " (Annotated)");

        Todo todo = todoService.get(UUID.fromString(todoId));

        SimpleMap<String, Object> model = new SimpleMap<>();
        if (todo != null) {
            model.put("pageTitle", "Todo Details (Annotated)");
            model.put("todo", todo);
            return new ActionResult("todos/details", model);
        } else {
            model.put("pageTitle", "Todo Not Found (Annotated)");
            model.put("todoId", todoId);
            return new ActionResult("todos/notfound", model, "404", "Not Found", "text/html; charset=utf-8");
        }
    }
}
