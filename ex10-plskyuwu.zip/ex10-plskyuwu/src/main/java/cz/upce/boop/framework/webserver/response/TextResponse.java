package cz.upce.boop.framework.webserver.response;

public class TextResponse extends BaseHttpResponse {

    public TextResponse(String content) {
        super("200", "OK");
        setBody(content, "text/html; charset=utf-8");
    }

    public TextResponse(String content, String statusCode, String reasonPhrase) {
        super(statusCode, reasonPhrase);
        setBody(content, "text/html; charset=utf-8");
    }

    public TextResponse(String content, String contentType) {
        super("200", "OK");
        setBody(content, contentType);
    }
}
