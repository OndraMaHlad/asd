package cz.upce.boop.framework.collection;

public record KeyValue<K, V>(K key, V value) {

}
