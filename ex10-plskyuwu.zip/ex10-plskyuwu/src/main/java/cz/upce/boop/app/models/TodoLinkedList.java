package cz.upce.boop.app.models;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.UUID;

public class TodoLinkedList implements Iterable<Todo> {

    private static class Node {
        Todo data;
        Node next;

        public Node(Todo data) {
            this.data = data;
            this.next = null;
        }
    }

    private int size;
    private Node head;

    public TodoLinkedList() {
        this.size = 0;
        this.head = null;
    }

    public void add(Todo todo) {
        Node newNode = new Node(todo);

        if (head == null || todo.compareTo(head.data) < 0) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;

            while (current.next != null &&
                    todo.compareTo(current.next.data) >= 0) {
                current = current.next;
            }

            newNode.next = current.next;
            current.next = newNode;
        }
        size++;
    }

    public Todo get(UUID id) {
        if (head == null) {
            return null;
        }

        if (head.data.id.equals(id)) {
            return head.data;
        }

        for (Todo todo : this) {
            if (todo.id.equals(id)) {
                return todo;
            }
        }

        return null;
    }

    public Todo remove(UUID id) {
        if (head == null) {
            return null;
        }

        if (head.data.id.equals(id)) {
            Todo removedTodo = head.data;
            head = head.next;
            size--;
            return removedTodo;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.data.id.equals(id)) {
                Todo removedTodo = current.next.data;
                current.next = current.next.next;
                size--;
                return removedTodo;
            }
            current = current.next;
        }

        return null;
    }

    public int size() {
        return size;
    }

    @Override
    public Iterator<Todo> iterator() {
        return new TodoIterator();
    }

    private class TodoIterator implements Iterator<Todo> {
        private Node current = head;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public Todo next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            Todo data = current.data;
            current = current.next;

            return data;
        }
    }
}
