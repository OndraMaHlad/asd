package cz.upce.boop.framework.webserver.mvc;

import cz.upce.boop.framework.webserver.request.HttpRequest;
import cz.upce.boop.framework.webserver.ProcessingContext;
import cz.upce.boop.framework.collection.SimpleMap;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Router {

    public record DiscoveredRoute(
            String httpMethod,
            String pathTemplate,
            Class<?> controllerClass, // The class containing the action method
            Method actionMethod // The actual method to invoke
            ) {

    }

    private final List<DiscoveredRoute> discoveredRoutes;

    public Router() {
        this.discoveredRoutes = new ArrayList<>();
    }

    /**
     * Scans the provided controller classes for methods annotated with
     *
     * @RoutePath and registers them.
     *
     * @param controllerClasses Classes to scan for routes.
     */
    public void registerControllers(Class<?>... controllerClasses) {
        System.out.println("Registering controllers...");
        for (Class<?> controllerClass : controllerClasses) {
            System.out.println("Scanning class: " + controllerClass.getName());
            for (Method method : controllerClass.getDeclaredMethods()) {
                if (method.isAnnotationPresent(RoutePath.class)) {
                    RoutePath routeAnnotation = method.getAnnotation(RoutePath.class);

                    // Basic validation of the annotated method signature
                    Class<?>[] paramTypes = method.getParameterTypes();
                    Class<?> returnType = method.getReturnType();

                    // Expecting: ActionResult action(ProcessingContext, SimpleMap<String, String>)
                    if (paramTypes.length == 2
                            && paramTypes[0].isAssignableFrom(ProcessingContext.class)
                            && paramTypes[1].isAssignableFrom(SimpleMap.class)
                            && // Check assignability
                            ActionResult.class.isAssignableFrom(returnType)) {
                        String httpMethod = routeAnnotation.method().toUpperCase();
                        String pathTemplate = routeAnnotation.path();
                        discoveredRoutes.add(new DiscoveredRoute(
                                httpMethod,
                                pathTemplate,
                                controllerClass,
                                method
                        ));
                        System.out.println("  -> Discovered route: " + httpMethod + " " + pathTemplate + " -> " + controllerClass.getSimpleName() + "." + method.getName());
                    } else {
                        System.err.println("Warning: Method " + controllerClass.getSimpleName() + "." + method.getName()
                                + " has @RoutePath annotation but incompatible signature. Expected (ProcessingContext, SimpleMap<String, String>) -> ActionResult.");
                    }
                }
            }
        }
        System.out.println("Controller registration complete. Found " + discoveredRoutes.size() + " routes.");
    }

    // MatchResult now includes controller class and method for invocation
    public record MatchResult(DiscoveredRoute route, SimpleMap<String, String> pathParams) {

    }

    public MatchResult match(HttpRequest request) {
        String requestMethod = request.getMethod().toUpperCase();
        String requestPath = request.getPath();

        // Normalize request path
        if (requestPath.length() > 1 && requestPath.endsWith("/")) {
            requestPath = requestPath.substring(0, requestPath.length() - 1);
        }
        String[] requestSegments = requestPath.split("/");

        for (DiscoveredRoute route : discoveredRoutes) {
            if (!route.httpMethod().equals(requestMethod)) {
                continue;
            }

            String templatePath = route.pathTemplate();
            // Normalize template path
            if (templatePath.length() > 1 && templatePath.endsWith("/")) {
                templatePath = templatePath.substring(0, templatePath.length() - 1);
            }
            String[] templateSegments = templatePath.split("/");

            if (requestSegments.length != templateSegments.length) {
                continue;
            }

            SimpleMap<String, String> pathParams = new SimpleMap<>();
            boolean match = true;
            for (int i = 0; i < templateSegments.length; i++) {
                String templateSegment = templateSegments[i];
                String requestSegment = requestSegments[i];

                if (templateSegment.startsWith("{") && templateSegment.endsWith("}")) {
                    String paramName = templateSegment.substring(1, templateSegment.length() - 1);
                    pathParams.put(paramName, requestSegment);
                } else {
                    if (!templateSegment.equals(requestSegment)) {
                        match = false;
                        break;
                    }
                }
            }

            if (match) {
                // System.out.println("Route matched: " + route.httpMethod() + " " + route.pathTemplate());
                return new MatchResult(route, pathParams);
            }
        }
        return null; // No match
    }
}
