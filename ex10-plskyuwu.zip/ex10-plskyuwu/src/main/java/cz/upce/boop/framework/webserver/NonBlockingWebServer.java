package cz.upce.boop.framework.webserver;

import cz.upce.boop.framework.webserver.response.TextResponse;
import cz.upce.boop.framework.webserver.response.BadRequestResponse;
import cz.upce.boop.framework.webserver.response.InternalServerErrorResponse;
import cz.upce.boop.framework.webserver.response.HttpResponse;
import cz.upce.boop.framework.webserver.request.HttpRequest;
import cz.upce.boop.framework.collection.KeyValue;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

public class NonBlockingWebServer implements TaskScheduler {

    private final int port;
    private ServerSocketChannel serverChannel;
    private Selector selector;
    private final MiddlewareNode middlewareChainHead; // Head of the linked list pipeline
    private final ByteBuffer buffer = ByteBuffer.allocate(8192);
    private final ConcurrentLinkedQueue<Runnable> taskQueue = new ConcurrentLinkedQueue<>();

    // Store ongoing processing contexts (Key -> Context mapping)
    // Using ArrayList<KeyValue> to simulate a Map as per constraints.
    private final ArrayList<KeyValue<SelectionKey, ProcessingContext>> activeContexts;
    private final Object contextLock = new Object(); // Lock for synchronizing access to activeContexts

    public NonBlockingWebServer(int port, MiddlewareNode middlewareChainHead) {
        this.port = port;
        this.activeContexts = new ArrayList<>();
        this.middlewareChainHead = middlewareChainHead;
        if (this.middlewareChainHead == null) {
            System.err.println("Warning: Middleware chain head is null!");
        }
    }

    // Implementation of TaskScheduler interface
    @Override
    public void schedule(Runnable task) {
        taskQueue.offer(task);
        if (selector != null && selector.isOpen()) {
            selector.wakeup(); // Wake up the selector if it's blocking in select()
        }
    }

    // --- Context Management Methods (addContext, getContext, removeContext - unchanged) ---
    private void addContext(SelectionKey key, ProcessingContext context) {
        synchronized (contextLock) {
            activeContexts.removeIf(kv -> kv.key().equals(key));
            activeContexts.add(new KeyValue<>(key, context));
        }
    }

    private ProcessingContext getContext(SelectionKey key) {
        synchronized (contextLock) {
            for (KeyValue<SelectionKey, ProcessingContext> kv : activeContexts) {
                if (kv.key().equals(key)) {
                    return kv.value();
                }
            }
        }
        return null;
    }

    private void removeContext(SelectionKey key) {
        synchronized (contextLock) {
            activeContexts.removeIf(kv -> kv.key().equals(key));
        }
    }

    // --- Server Start and Main Loop ---
    public void start() throws IOException {
        selector = Selector.open();
        serverChannel = ServerSocketChannel.open();
        serverChannel.bind(new InetSocketAddress(port));
        serverChannel.configureBlocking(false);
        serverChannel.register(selector, SelectionKey.OP_ACCEPT);

        System.out.println("Linked List Pipeline Server started on port " + port);

        while (true) {
            processPendingTasks(); // Process tasks scheduled from other threads/callbacks

            int readyChannels = selector.select(); // Blocks until events or wakeup()

            processPendingTasks(); // Process tasks again in case select() was woken up

            if (readyChannels == 0 && taskQueue.isEmpty()) {
                continue; // Spurious wakeup or task already processed
            }

            Set<SelectionKey> selectedKeys = selector.selectedKeys();
            Iterator<SelectionKey> keyIterator = selectedKeys.iterator();

            while (keyIterator.hasNext()) {
                SelectionKey key = keyIterator.next();
                keyIterator.remove(); // Remove immediately

                if (!key.isValid()) {
                    cleanupConnection(key);
                    continue;
                }

                try {
                    if (key.isAcceptable()) {
                        handleAccept(key);
                    } else if (key.isReadable()) {
                        handleRead(key);
                    } else if (key.isWritable()) {
                        handleWrite(key);
                    }
                } catch (CancelledKeyException e) {
                    System.err.println("Key cancelled during processing: " + key.attachment());
                    cleanupConnection(key);
                } catch (IOException e) {
                    System.err.println("IOException during key processing (" + key.readyOps() + "): " + e.getMessage());
                    cleanupConnection(key);
                } catch (Exception e) {
                    System.err.println("Unexpected error processing key: " + e.getMessage());
                    e.printStackTrace();
                    // Attempt to send error response if possible
                    ProcessingContext context = getContext(key);
                    if (context != null && !context.hasResponse()) {
                        context.setResponse(new InternalServerErrorResponse("Server error during processing"));
                        try {
                            if (key.isValid()) {
                                key.interestOps(SelectionKey.OP_WRITE);
                            }
                        } catch (CancelledKeyException ignored) {
                        }
                    }
                    cleanupConnection(key); // Close connection after unexpected error
                }
            } // end while keyIterator
        } // end while true
    }

    private void processPendingTasks() {
        Runnable task;
        while ((task = taskQueue.poll()) != null) {
            try {
                // System.out.println("Executing scheduled task on IO thread."); // Optional debug log
                task.run();
            } catch (Exception e) {
                System.err.println("Error executing scheduled task: " + e.getMessage());
                e.printStackTrace();
                // Potentially find associated key/context and trigger error response? Difficult.
            }
        }
    }

    // --- Event Handling Methods ---
    private void handleAccept(SelectionKey key) throws IOException {
        ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key.channel();
        SocketChannel clientChannel = serverSocketChannel.accept(); // Non-blocking
        if (clientChannel != null) {
            clientChannel.configureBlocking(false);
            SelectionKey clientKey = clientChannel.register(selector, SelectionKey.OP_READ);
            // Attach a buffer immediately for potential partial reads
            clientKey.attach(ByteBuffer.allocate(8192));
            System.out.println("Accepted connection from: " + clientChannel.getRemoteAddress());
        }
    }

    private void handleRead(SelectionKey key) throws IOException {
        SocketChannel clientChannel = (SocketChannel) key.channel();
        ProcessingContext context = getContext(key); // Check if context already exists (e.g., from previous partial read)

        ByteBuffer readBuffer = (ByteBuffer) key.attachment();
        if (readBuffer == null) { // Should not happen if attached in accept, but safety check
            System.err.println("Error: Missing buffer attachment for reading on key.");
            readBuffer = ByteBuffer.allocate(8192);
            key.attach(readBuffer);
        }

        // Use a temporary buffer to read new data
        buffer.clear();
        int bytesRead = -1;
        try {
            bytesRead = clientChannel.read(buffer);
        } catch (IOException e) {
            System.err.println("IOException during read from " + clientChannel.getRemoteAddress() + ": " + e.getMessage());
            cleanupConnection(key);
            return;
        }

        if (bytesRead == -1) {
            System.out.println("Client closed connection: " + clientChannel.getRemoteAddress());
            cleanupConnection(key);
            return;
        }

        if (bytesRead > 0) {
            buffer.flip();
            // Ensure capacity before putting into attached buffer
            if (readBuffer.remaining() < buffer.limit()) {
                // Resize needed - more complex buffer management required for large requests
                // For simplicity, assume initial 8k is enough or send error
                System.err.println("Request exceeds buffer capacity for " + clientChannel.getRemoteAddress());
                if (context == null) { // Create context just for error
                    context = new ProcessingContext(null, key, this, this);
                    addContext(key, context);
                }
                context.setResponse(new TextResponse("Payload Too Large", "413", "Payload Too Large"));
                key.interestOps(SelectionKey.OP_WRITE);
                key.attach(null); // Remove buffer
                return;
            }
            readBuffer.put(buffer); // Append new data to the attached buffer

            // Try to parse the request from the accumulated data in the attached buffer
            HttpRequest request = null;
            try {
                // Pass the attached buffer to parse, parse() should handle flip/compact/clear
                request = HttpRequest.parse(readBuffer);
            } catch (IllegalArgumentException e) {
                System.err.println("Bad request received from " + clientChannel.getRemoteAddress() + ": " + e.getMessage());
                if (context == null) {
                    context = new ProcessingContext(null, key, this, this);
                    addContext(key, context);
                }
                context.setResponse(new BadRequestResponse(e.getMessage()));
                key.interestOps(SelectionKey.OP_WRITE);
                key.attach(null); // Clear attachment
                return;
            }

            if (request != null) {
                // Request parsed successfully
                System.out.println("Received request: " + request.getMethod() + " " + request.getPath());
                if (context == null) { // Create context if it wasn't already there
                    context = new ProcessingContext(request, key, this, this);
                    addContext(key, context);
                }
                key.attach(null); // Clear the attachment buffer, no longer needed

                // Start the pipeline processing using the linked list head
                if (middlewareChainHead != null) {
                    middlewareChainHead.executeChain(context);
                } else {
                    System.err.println("Middleware chain is not configured!");
                    context.setResponse(new InternalServerErrorResponse("Server configuration error: No middleware chain."));
                }

                // After sync pipeline execution attempt, check if response is ready
                // Asynchronous handlers might set the response later via scheduled tasks.
                // The triggerWriteIfNeeded logic within MiddlewareNode handles setting OP_WRITE.
                if (context.hasResponse() && (key.interestOps() & SelectionKey.OP_WRITE) == 0) {
                    // If response is ready now and write isn't set, set it.
                    key.interestOps(SelectionKey.OP_WRITE);
                } else if (!context.hasResponse()) {
                    // Pipeline processing deferred (async) or ended without response (error handled internally)
                    System.out.println("Pipeline processing deferred or completed without immediate response for: " + request.getPath());
                    // Keep OP_READ? Generally no, async handler should set OP_WRITE when ready.
                    // key.interestOps(key.interestOps() & ~SelectionKey.OP_READ); // Optional: pause reading
                }
                // If context has response AND OP_WRITE is already set (by async handler), do nothing here.

            } else {
                // Request is incomplete, need more data
                System.out.println("Incomplete request received from " + clientChannel.getRemoteAddress() + ", waiting for more data...");
                // Keep OP_READ interest, buffer is already compacted by parse()
                key.interestOps(SelectionKey.OP_READ);
            }
        }
        // If bytesRead == 0, do nothing, just wait for more data (keep OP_READ)
    }

    private void handleWrite(SelectionKey key) throws IOException {
        SocketChannel clientChannel = (SocketChannel) key.channel();
        ProcessingContext context = getContext(key);

        if (context == null || !context.hasResponse()) {
            System.err.println("Error: OP_WRITE triggered but no context or response ready. Key: " + key + " Addr: " + clientChannel.getRemoteAddress());
            // This might happen if an error occurred and cleanup happened before write
            // Or if OP_WRITE was set prematurely.
            key.interestOps(key.interestOps() & ~SelectionKey.OP_WRITE); // Remove write interest
            // Consider closing if state is inconsistent
            // cleanupConnection(key);
            return;
        }

        HttpResponse response = context.getResponse();
        System.out.println("Sending response for: " + (context.getRequest() != null ? context.getRequest().getPath() : "[Error Response]") + " to " + clientChannel.getRemoteAddress());

        try {
            // Write the response (BaseHttpResponse handles buffering)
            response.writeToChannel(clientChannel);

            // TODO: Handle partial writes robustly. If writeToChannel indicates incomplete write,
            // keep OP_WRITE interest and store remaining data/buffer state in context/attachment.
            // For this example, we assume complete write or IOException.
            System.out.println("Response sent, closing connection for " + clientChannel.getRemoteAddress());
            cleanupConnection(key); // Close after successful write (HTTP/1.1 close behavior)

        } catch (IOException e) {
            System.err.println("IOException during write to " + clientChannel.getRemoteAddress() + ": " + e.getMessage());
            cleanupConnection(key); // Close on write error
        }
    }

    // --- Utility Methods ---
    // Renamed from closeChannel to emphasize context removal
    public void cleanupConnection(SelectionKey key) {
        if (key == null) {
            return;
        }

        removeContext(key); // Remove associated context first
        key.cancel();
        try {
            key.channel().close();
            // System.out.println("Closed connection associated with key."); // Optional log
        } catch (IOException cex) {
            System.err.println("Error closing channel during cleanup: " + cex.getMessage());
        } catch (ClassCastException cce) {
            // Handle case where channel might be ServerSocketChannel if error happens early
            try {
                key.channel().close();
            } catch (IOException ignored) {
            }
        } finally {
            key.attach(null); // Clean attachment
        }
    }

    public void stop() throws IOException {
        System.out.println("Stopping server...");
        if (selector != null && selector.isOpen()) {
            // Close all client connections gracefully
            Set<SelectionKey> keys = selector.keys();
            for (SelectionKey key : keys) {
                if (key.channel() instanceof SocketChannel) {
                    System.out.println("Closing client connection during shutdown: " + key.channel());
                    cleanupConnection(key);
                } else if (key.channel() instanceof ServerSocketChannel) {
                    key.cancel();
                    key.channel().close(); // Close server socket
                }
            }
            selector.close();
            System.out.println("Selector closed.");
        }
        // Server channel might already be closed by iterating keys, but check again
        if (serverChannel != null && serverChannel.isOpen()) {
            serverChannel.close();
            System.out.println("Server socket closed.");
        }
        taskQueue.clear(); // Clear pending tasks
        activeContexts.clear(); // Clear any remaining contexts
        System.out.println("Server stopped.");
    }
}
