package cz.upce.boop.app.controllers;

import cz.upce.boop.app.models.Product;
import cz.upce.boop.app.models.ProductService;
import cz.upce.boop.framework.webserver.mvc.ActionResult;
import cz.upce.boop.framework.webserver.ProcessingContext;
import cz.upce.boop.framework.webserver.mvc.RoutePath;
import cz.upce.boop.framework.collection.SimpleMap;
import cz.upce.boop.framework.di.Inject;
import cz.upce.boop.framework.webserver.mvc.RedirectActionResult;

public class ProductController {

    private final ProductService productService;

    @Inject
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @RoutePath(path = "/products/{id}", method = "GET")
    public ActionResult showProduct(ProcessingContext context, SimpleMap<String, String> pathParams) {
        String productId = pathParams.get("id");
        System.out.println("ProductController.showProduct called for ID: " + productId + " (Annotated)");
        
        Product product = productService.get(productId);
        
        SimpleMap<String, Object> model = new SimpleMap<>();
        if (product != null) {
            model.put("pageTitle", "Product Details (Annotated)");
            model.put("product", product);
            return new ActionResult("products/details", model);
        } else {
            model.put("pageTitle", "Product Not Found (Annotated)");
            model.put("productId", productId);
            return new ActionResult("products/notfound", model, "404", "Not Found", "text/html; charset=utf-8");
        }
    }

    @RoutePath(path = "/products", method = "GET")
    public ActionResult listProducts(ProcessingContext context, SimpleMap<String, String> pathParams) {
        System.out.println("ProductController.listProducts called (Annotated)");
        
        SimpleMap<String, Object> model = new SimpleMap<>();
        model.put("pageTitle", "Product List (Annotated)");
        model.put("allProducts", productService.getProducts());
        model.put("productCount", productService.size());
        return new ActionResult("products/list", model);
    }
    
    @RoutePath(path = "/products-create", method = "POST")
    public ActionResult create(ProcessingContext context, SimpleMap<String, String> params) {
        // Extract form data from params
        String id = params.get("id");
        String name = params.get("name");
        String price = params.get("price");
        
        // Validate input
        if (name == null || name.isEmpty()) {
            SimpleMap<String, Object> errorModel = new SimpleMap<>();
            errorModel.put("error", "Title is required");
            return new ActionResult("products/error", errorModel);
        }

        // Create new product
        productService.add(id, name, price);
        
        // Redirect to index page after successful creation
        return new RedirectActionResult("/products");
    }

    @RoutePath(path = "/products-delete/{id}", method = "POST")
    public ActionResult delete(ProcessingContext context, SimpleMap<String, String> params) {
        // Extract form data from params
        String id = params.get("id");
        
        // Delete product 
        productService.remove(id);
        
        // Redirect to index page after successful deletion
        return new RedirectActionResult("/products");
    }
}
