package cz.upce.boop.framework.webserver;

public interface TaskScheduler {

    void schedule(Runnable task);
}
